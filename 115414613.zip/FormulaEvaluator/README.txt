```
Author:     H. James de St. Germain          
Partner:    None
Date:       21-Jan-2022
Course:     CS 3500, University of Utah, School of Computing
GitHub ID:  notrh99
Repo:       https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-notrh99.git
Commit #:   d8f86329fd6975cd4368b3feaddaf9c503d2c533
Solution:   FormulaEvaluator
Copyright:  CS 3500 and Rayyan Hamid - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators:

The Spreadsheet program is currently capable of doing basis artrimatic functions, for example add, subtract, multiply and divide.

# Time Expenditures:

    1. Assignment One:   Predicted Hours:          10        Actual Hours:       10

# References:

    1. For Regex - https://docs.microsoft.com/en-us/dotnet/api/system.text.regularexpressions.regex.ismatch?view=net-6.0