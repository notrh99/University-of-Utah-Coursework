﻿```
Author:     Iris Yang 
Partner:    Rayyan Hamid 
Date:       4/Mar/2022
Course:     CS 3500, University of Utah, School of Computing
GitHub ID:  iristhevirus0
Repo:       https://github.com/orgs/Utah-School-of-Computing-de-St-Germain/teams/runtimeterror
Commit #:   53c3f4022d31263235edc852dc17a8c0c49627c7
Project:    GUI
Copyright:  CS 3500 and Iris Yang - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators:

    When the name text box or value text box are mouse-clicked, then the key presseing is not working.
    Please stay on selecting content text box

# Assignment Specific Topics

    Our special feature for spreadsheet GUI is changing background color of spreadsheet.
    If you click the color menu, it will ask if you like current color or not. If you clikcked you don't like it,
    then it will change to new randomly generated color. 

# Consulted Peers: 

    No one

# References: 

    1. Assignment instruction - https://utah.instructure.com/courses/754704/assignments/10141498
    2. Lectures from class
    4. MessageBox document- https://docs.microsoft.com/en-us/dotnet/api/system.windows.forms.messagebox?view=windowsdesktop-6.0
    3. Example code  - https://github.com/Utah-School-of-Computing-de-St-Germain/ForStudents/tree/main/Examples/Spreadsheet_GUI_Example