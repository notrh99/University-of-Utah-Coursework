﻿``````
Author:     Rayyan Hamid          
Partner:    None
Date:       14-Feb-2022
Course:     CS 3500, University of Utah, School of Computing
GitHub ID:  notrh99
Repo:       https://github.com/Utah-School-of-Computing-de-St-Germain/spreadsheet-notrh99.git
Commit #:   d8f86329fd6975cd4368b3feaddaf9c503d2c533
Solution:   DependencyGraph
Copyright:  CS 3500 and Rayyan Hamid - This work may not be copied for use in Academic Coursework.
```

# Comments to Evaluators:

The Spreadsheet program is currently capable of doing basis artrimatic functions, for example add, subtract, multiply and divide. 
The Spreadsheet is now able hanble dependencies between multiple cells in a spreadsheet.

# Time Expenditures:

    1. Assignment One:   Predicted Hours:          10        Actual Hours:       10
    2. Assignment Two:   Predicted Hours:          10        Actual Hours:       8
    3. Assignment Three  Predicted Hours:          10        Actual Hours:       14
    4. Assignment Four   Predicted Hours:          10        Actual Hours:       6


# References:
